What is this folder about?

It serves two purposes!

(1)
Even without building the project by yourself, you can already take a look
at the four existing title pages that you can select from. The number four
arises from having two completely different styles (the 01 versions versus
the 02 versions), times honours versus non-honours project, as the text
displayed there is slightly different.

Note that for three PDFs you see *only* the title page, whereas one of them also
shows the entire content of the document -- which bringt me to the next point.

(2)
You can read all the advice just for the sake of getting that advice,
even when you are not intending to use the actual LaTeX template.

And even if you end up using this document, you will always have this
pre-compiled PDF available to look up the advice -- as otherwise you are
going to replace it by your work's content.

